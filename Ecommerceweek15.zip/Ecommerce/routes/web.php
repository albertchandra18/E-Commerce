<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomepageController@index');

Route::get('/about', 'HomepageController@about');
Route::get('/kontak', 'HomepageController@kontak');

Route::get('/kategori', 'HomepageController@kategori');
Route::get('/galeri', 'GaleriController@index');
Route::get('/vincent', 'VincentController@index');

Route::group(['prefix' => 'admin'], function() {
    Route::get('/', 'DashboardController@index');
    Route::resource('kategori', 'KategoriController');
    Route::resource('produk', 'ProdukController');
    Route::resource('customer', 'CustomerController');
    Route::resource('transaksi', 'TransaksiController');
    Route::get('profil', 'UserController@index');
    Route::get('setting', 'UserController@setting');
    Route::get('laporan', 'LaporanController@index');
    Route::get('proseslaporan', 'LaporanController@proses');
  });


