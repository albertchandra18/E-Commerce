<div class="container">
  <div class="row">
    <div class="col">
      <hr />
      <p>&copy Copyright Web Ecommerce Prodi SI - 2021</p>
    </div>
  </div>
</div>