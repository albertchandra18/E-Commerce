
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <!-- fontawesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <title><?php echo e($title); ?></title>
  </head>
  <body>
        
        <?php $__env->startSection('content'); ?>
        <div class="container">
        <!-- carousel -->
        <div class="row">
            <div class="col">
            <div id="carousel" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?php echo e(asset('images/slide1.jpg')); ?>" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="<?php echo e(asset('images/slide2.jpg')); ?>" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="<?php echo e(asset('images/slide3.jpg')); ?>" class="d-block w-100" alt="...">
                </div>
                </div>
                <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
                </a>
            </div>
            </div>
        </div>
        <!-- end carousel -->
        <!-- kategori produk -->
        <div class="row mt-4">
            <div class="col col-md-12 col-sm-12 mb-4">
            <h2 class="text-center">Kategori Produk</h2>
            </div>
            <!-- kategori pertama -->
            <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
                <a href="<?php echo e(URL::to('kategori/satu')); ?>">
                <img src="<?php echo e(asset('images/slide1.jpg')); ?>" alt="foto kategori" class="card-img-top">
                </a>
                <div class="card-body">
                <a href="<?php echo e(URL::to('kategori/satu')); ?>" class="text-decoration-none">
                    <p class="card-text">Kategori Pertama</p>
                </a>
                </div>
            </div>
            </div>
            <!-- kategori kedua -->
            <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
                <a href="<?php echo e(URL::to('kategori/dua')); ?>">
                <img src="<?php echo e(asset('images/slide1.jpg')); ?>" alt="foto kategori" class="card-img-top">
                </a>
                <div class="card-body">
                <a href="<?php echo e(URL::to('kategori/dua')); ?>" class="text-decoration-none">
                    <p class="card-text">Kategori Kedua</p>
                </a>
                </div>
            </div>
            </div>
            <!-- kategori ketiga -->
            <div class="col-md-4">
            <div class="card mb-4 shadow-sm">
                <a href="<?php echo e(URL::to('kategori/tiga')); ?>">
                <img src="<?php echo e(asset('images/slide1.jpg')); ?>" alt="foto kategori" class="card-img-top">
                </a>
                <div class="card-body">
                <a href="<?php echo e(URL::to('kategori/tiga')); ?>" class="text-decoration-none">
                    <p class="card-text">Kategori Ketiga</p>
                </a>
                </div>
            </div>
            </div>
        </div>
        <!-- end kategori produk -->
        </div>
        <?php $__env->stopSection(); ?>

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" 
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

  </body>
</html>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ECommerce\Ecommerce\resources\views/homepage/index.blade.php ENDPATH**/ ?>